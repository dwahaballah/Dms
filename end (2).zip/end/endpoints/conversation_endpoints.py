from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
import json
from sqlalchemy import desc
# Adjust these imports according to your project's structure.
from database import get_db
from models import SystemPrompt
from models import User
from models import ConversationRecord
from endpoints.user_endpoints import get_current_user
router = APIRouter()

@router.get("/user/conversations")
def get_all_conversations(
    # current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    conversations = db.query(ConversationRecord).filter(
        ConversationRecord.user_id == current_user.id
    ).order_by(desc(ConversationRecord.created_at)).all()
 
    if not conversations:
        return JSONResponse(content={"message": "No conversation history found", "conversations": []})
 
    conversation_list = [
            {
                "conversation_id": conv.conversation_id,
                "history": json.loads(conv.history),
                "created_at": conv.created_at.isoformat() if conv.created_at else None
            }
            for conv in conversations
        ]

    return JSONResponse(content={
        "conversations": conversation_list
    })
    
# @router.get("/user/{user_id}")
# async def get_user_conversations(user_id: int, db: Session = Depends(get_db)):
#     conversations = db.query(ConversationRecord).filter(
#         ConversationRecord.user_id == user_id
#     ).all()

#     return JSONResponse(content={
#         "conversations": [
#             {"conversation_id": conv.conversation_id, "history": json.loads(conv.history),  "created_at": conv.created_at.isoformat() if conv.created_at else None}
#             for conv in conversations
#         ]
#     })

@router.delete("/{conversation_id}")
async def delete_conversation(conversation_id: str, db: Session = Depends(get_db)):
    conversation = db.query(ConversationRecord).filter(ConversationRecord.conversation_id == conversation_id).first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
    db.delete(conversation)
    db.commit()
    return {"detail": "Conversation deleted successfully"}

@router.get("/{conversation_id}")
async def get_conversation(
    conversation_id: str,
    # current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    conversation = db.query(ConversationRecord).filter(
        ConversationRecord.conversation_id == conversation_id,
        ConversationRecord.user_id == current_user.id
    ).first()
 
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")
 
    return {
        "conversation_id": conversation_id,
        "history": json.loads(conversation.history)
    }
