from fastapi import APIRouter, Depends, HTTPException, Form, File, UploadFile
from fastapi.responses import JSONResponse
from typing import List, Optional
from sqlalchemy.orm import Session
from pydantic import BaseModel
import tempfile, time, random, array, uuid, json, logging
import logging
import json
import tempfile
import uuid
import random
import time
import array
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from sqlalchemy import text, or_
from endpoints.user_endpoints import get_current_user
from database import get_db
from models import SystemPrompt, User, Channel, FileRecord, ChannelUser, FileEmbeddings
from utils.file_utils import allowed_file, convert_to_text
from utils.embedding_utils import get_embedding
from endpoints.file_endpoints import upload_file
from datetime import datetime
router = APIRouter()
 
class ChannelPrompt(BaseModel):
    name: str
    content: str
 

# Setup logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
 


@router.post("/")
async def create_channel_with_files(
    channel_name: str = Form(...),
    description: str = Form(...),
    is_visible: str = Form(...),
    admin_user_id: str = Form(...),
    user_ids: Optional[str] = Form("[]"),
    prompt: Optional[str] = Form("{}"),
    files: List[UploadFile] = File(default=[]),  # Allow multiple files or none
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    logger.info("Request received to create channel '%s' by user '%s' (role=%s)",
                channel_name, current_user.username, current_user.role)
    # Check permissions
    if current_user.role != "super":
        logger.warning("Unauthorized attempt by user '%s' to create channel", current_user.username)
        raise HTTPException(status_code=403, detail="Only super admins can create channels.")
    try:
        # Parse request data
        logger.debug("Parsing request body for admin_user_id, user_ids, and prompt")
        try:
            admin_username = json.loads(admin_user_id) 
            user_ids_list = json.loads(user_ids)
            prompt_data = json.loads(prompt)
        except json.JSONDecodeError as e:
            logger.error("JSON parsing error: %s", str(e))
            raise HTTPException(status_code=400, detail="Invalid JSON format in request data")
        # Validate admin user exists
        admin_user = db.query(User).filter(User.username == admin_username).first()
        if not admin_user:    
            raise HTTPException(status_code=404, detail=f"Admin user '{admin_username}' not found")
        # Validate all users exist before creating channel
        valid_users = []
        for username in user_ids_list:
            user = db.query(User).filter(User.username == username).first()
            if user:
                valid_users.append(user)
            else:
                logger.warning("User '%s' not found, skipping", username)
        # Create channel
        new_channel = Channel(
            name=channel_name,  # Changed from channel_name to name
            description=description,
            is_active=1 if is_visible.lower() == "true" else 0,  # Changed to is_active and use 1/0 for Oracle
            admin_user_id=admin_user.id,  # Add the admin_user_id field
            created_by=current_user.id
        )
        db.add(new_channel)
        db.commit()  # Get the ID without committing yet
        logger.info("Channel created: id=%s, name=%s", new_channel.id, channel_name)
        # Assign admin to channel (admin is already set in the Channel model)
        # Note: The admin_user_id in Channel table tracks who is the admin
        # We still add them to ChannelUser for consistency in permissions
        channel_admin = ChannelUser(
            user_id=admin_user.id, 
            channel_id=new_channel.id, 
            added_by=current_user.id
        )
        db.add(channel_admin)
        logger.debug("Admin assigned to channel: user_id=%s", admin_user.id)
        # Assign regular users to channel
        for user in valid_users:
            if user.id != admin_user.id:  # Don't add admin twice
                channel_user = ChannelUser(
                    user_id=user.id, 
                    channel_id=new_channel.id, 
                    added_by=current_user.id
                )
                db.add(channel_user)
                logger.debug("User assigned to channel: user_id=%s", user.id)
        # Add system prompt (if provided)
        if prompt_data and "name" in prompt_data and "content" in prompt_data:
            system_prompt = SystemPrompt(
                name=prompt_data["name"],
                content=prompt_data["content"],
                user_id=current_user.id,
                channel_id=new_channel.id
            )
            db.add(system_prompt)
            logger.info("System prompt added to channel %s by user %s", new_channel.id, current_user.id)
        # Upload files (if provided)
        uploaded_files = []
        for file in files:
            if file.filename:  # Check if file is actually provided
                try:
                    # You'll need to modify your upload_file function to accept channel_id
                    result = await upload_file(
                        file=file, 
                        db=db, 
                        current_user=current_user, 
                        channel_id=new_channel.id
                    )
                    uploaded_files.append(result)
                    logger.info("File uploaded to channel: %s", file.filename)
                except Exception as e:
                    logger.error("Failed to upload file %s: %s", file.filename, str(e))
                    # Continue with other files, don't fail the entire operation
        # Commit all changes at once
        db.commit()
        logger.info("Channel creation process completed successfully: channel_id=%s", new_channel.id)
        return {
            "message": "Channel created successfully",
            "channel_id": new_channel.id,
            "channel_name": channel_name,
            "admin_user": admin_username,
            "users_added": len(valid_users),
            "files_uploaded": len(uploaded_files),
            "has_prompt": bool(prompt_data and "name" in prompt_data)
        }
    except HTTPException:
        db.rollback()
        raise  # Re-raise HTTP exceptions
    except Exception as e:
        db.rollback()
        logger.error("Channel creation failed: %s", str(e), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to create channel: {str(e)}")
 
 
@router.get("/getchannels")

async def get_user_channels(

    include_files: bool = True,  # Optional query parameter to include files

    db: Session = Depends(get_db),

    current_user: User = Depends(get_current_user)  # ✅ UNCOMMENTED AND FIXED

):

    """Get all channels accessible to the current user with optional file details"""

    logger.info("Fetching channels for user '%s' (role=%s), include_files=%s",

                current_user.username, current_user.role, include_files)  # ✅ FIXED

    try:

        if current_user.role == "super":

            # Super admin can see all active channels

            channels = db.query(Channel).filter(Channel.is_active == 1).all()

        else:

            # Regular users see channels they have access to

            channels = db.query(Channel).filter(

                Channel.is_active == 1

            ).filter(

                or_(

                    Channel.admin_user_id == current_user.id,  # User is admin

                    Channel.id.in_(  # User is member

                        db.query(ChannelUser.channel_id).filter(

                            ChannelUser.user_id == current_user.id

                        )

                    )

                )

            ).all()

        # Build response with additional info

        result = []

        for channel in channels:

            admin_user = db.query(User).filter(User.id == channel.admin_user_id).first()

            member_count = db.query(ChannelUser).filter(ChannelUser.channel_id == channel.id).count()

            # Get files for this channel

            if include_files:

                files_query = db.query(FileRecord, User.username).join(

                    User, FileRecord.user_id == User.id

                ).filter(FileRecord.channel_id == channel.id).all()

                files_data = [

                    {

                        "file_id": file.file_id,

                        "filename": file.filename,

                        "upload_type": file.upload_type,

                        "uploaded_by": username,

                        "pages": file.source,  # page count

                        "created_at": getattr(file, 'created_at', None)  # if you have this field

                    } for file, username in files_query

                ]

                file_count = len(files_data)

            else:

                files_data = []

                file_count = db.query(FileRecord).filter(FileRecord.channel_id == channel.id).count()

            channel_data = {

                "id": channel.id,

                "name": channel.name,

                "description": channel.description,

                "admin_user": admin_user.username if admin_user else None,

                "created_at": channel.created_at,

                "updated_at": channel.updated_at,

                "member_count": member_count,

                "file_count": file_count,

                "user_role": "admin" if channel.admin_user_id == current_user.id else "member"

            }

            # Only include files if requested

            if include_files:

                channel_data["files"] = files_data

            result.append(channel_data)

        return {"channels": result}

    except Exception as e:

        logger.error("Failed to fetch channels: %s", str(e))

        raise HTTPException(status_code=500, detail="Failed to fetch channels")
 

@router.get("/{channel_id}")
async def get_channel_details(
    channel_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get detailed information about a specific channel"""
    
    # Check if user has access to this channel
    if not has_channel_access(db, current_user.id, channel_id):
        raise HTTPException(status_code=403, detail="Access denied to this channel")
    
    try:
        channel = db.query(Channel).filter(
            Channel.id == channel_id,
            Channel.is_active == 1
        ).first()
        
        if not channel:
            raise HTTPException(status_code=404, detail="Channel not found")
        
        # Get admin info
        admin_user = db.query(User).filter(User.id == channel.admin_user_id).first()
        
        # Get members
        members = db.query(User, ChannelUser.added_at).join(
            ChannelUser, User.id == ChannelUser.user_id
        ).filter(ChannelUser.channel_id == channel_id).all()
        
        # Get files
        files = db.query(FileRecord).filter(FileRecord.channel_id == channel_id).all()
        
        # Get prompts
        prompts = db.query(SystemPrompt).filter(SystemPrompt.channel_id == channel_id).all()
        
        return {
            "id": channel.id,
            "name": channel.name,
            "description": channel.description,
            "admin_user": {
                "id": admin_user.id,
                "username": admin_user.username
            } if admin_user else None,
            "created_at": channel.created_at,
            "updated_at": channel.updated_at,
            "members": [
                {
                    "id": user.id,
                    "username": user.username,
                    "added_at": added_at
                } for user, added_at in members
            ],
            "files": [
                {
                    "file_id": file.file_id,
                    "filename": file.filename,
                    "upload_type": file.upload_type
                } for file in files
            ],
            "prompts": [
                {
                    "id": prompt.id,
                    "name": prompt.name,
                    "content": prompt.content
                } for prompt in prompts
            ],
            "user_role": "admin" if channel.admin_user_id == current_user.id else "member"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get channel details: %s", str(e))
        raise HTTPException(status_code=500, detail="Failed to get channel details")

@router.put("/{channel_id}")
async def update_channel(
    channel_id: int,
    name: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    is_visible: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update channel information (admin only)"""
    
    try:
        channel = db.query(Channel).filter(
            Channel.id == channel_id,
            Channel.is_active == 1
        ).first()
        
        if not channel:
            raise HTTPException(status_code=404, detail="Channel not found")
        
        # Check permissions - only admin or super admin can edit
        if current_user.role != "super" and channel.admin_user_id != current_user.id:
            raise HTTPException(status_code=403, detail="Only channel admin can edit channel")
        
        # Update fields if provided
        if name is not None:
            channel.name = name
        if description is not None:
            channel.description = description
        if is_visible is not None:
            channel.is_active = 1 if is_visible.lower() == "true" else 0
        
        channel.updated_at = datetime.utcnow()
        
        db.commit()
        logger.info("Channel %s updated by user %s", channel_id, current_user.username)
        
        return {
            "message": "Channel updated successfully",
            "channel_id": channel_id,
            "name": channel.name,
            "description": channel.description,
            "is_active": bool(channel.is_active)
        }
        
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error("Failed to update channel: %s", str(e))
        raise HTTPException(status_code=500, detail="Failed to update channel")

@router.delete("/{channel_id}")
async def delete_channel(
    channel_id: int,
    permanent: bool = True,  # Query parameter for permanent deletion
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete a channel (super admin only)
    - permanent=false: Soft delete (default) - marks as inactive
    - permanent=true: Hard delete - completely removes from database
    """
    if current_user.role != "super":
        raise HTTPException(status_code=403, detail="Only super admins can delete channels")
    try:
        channel = db.query(Channel).filter(Channel.id == channel_id).first()
        if not channel:
            raise HTTPException(status_code=404, detail="Channel not found")
        if permanent:
            # HARD DELETE - Remove everything related to this channel
            logger.warning("Performing PERMANENT deletion of channel %s by %s", 
                          channel_id, current_user.username)
            # Delete in this order to respect foreign key constraints:
            # 1. Delete file embeddings first
            file_ids = db.query(FileRecord.file_id).filter(FileRecord.channel_id == channel_id).all()
            if file_ids:
                file_id_list = [fid[0] for fid in file_ids]
                db.query(FileEmbeddings).filter(FileEmbeddings.file_id.in_(file_id_list)).delete()
                logger.debug("Deleted embeddings for %d files", len(file_id_list))

            
            # 3. Delete files in this channel
            files_deleted = db.query(FileRecord).filter(
                FileRecord.channel_id == channel_id
            ).delete()
            logger.debug("Deleted %d files", files_deleted)
            # 4. Delete system prompts in this channel
            prompts_deleted = db.query(SystemPrompt).filter(
                SystemPrompt.channel_id == channel_id
            ).delete()
            logger.debug("Deleted %d prompts", prompts_deleted)
            # 5. Delete channel users (membership)
            members_deleted = db.query(ChannelUser).filter(
                ChannelUser.channel_id == channel_id
            ).delete()
            logger.debug("Deleted %d channel memberships", members_deleted)
            # 6. Finally, delete the channel itself
            db.delete(channel)
            db.commit()
            logger.warning("Channel %s PERMANENTLY deleted by super admin %s", 
                          channel_id, current_user.username)
            return {
                "message": "Channel permanently deleted",
                "channel_id": channel_id,
                "deletion_type": "permanent",
                "items_deleted": {
                    "files": files_deleted,
                    "prompts": prompts_deleted,
                    "memberships": members_deleted
                }
            }
        else:
            # SOFT DELETE - Just mark as inactive (default behavior)
            channel.is_active = 0
            channel.updated_at = datetime.utcnow()
            db.commit()
            logger.info("Channel %s soft deleted (deactivated) by super admin %s", 
                       channel_id, current_user.username)
            return {
                "message": "Channel deactivated successfully", 
                "channel_id": channel_id,
                "deletion_type": "soft",
                "note": "Channel is hidden but data is preserved. Use permanent=true to completely delete."
            }
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error("Failed to delete channel: %s", str(e))
        raise HTTPException(status_code=500, detail="Failed to delete channel")


@router.post("/{channel_id}/users")
async def add_user_to_channel(
    channel_id: int,
    username: str = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Add a user to a channel (admin only)"""
    
    try:
        channel = db.query(Channel).filter(
            Channel.id == channel_id,
            Channel.is_active == 1
        ).first()
        
        if not channel:
            raise HTTPException(status_code=404, detail="Channel not found")
        
        # Check permissions - only admin or super admin can add users
        if current_user.role != "super" and channel.admin_user_id != current_user.id:
            raise HTTPException(status_code=403, detail="Only channel admin can add users")
        
        # Find user to add
        user_to_add = db.query(User).filter(User.username == username).first()
        if not user_to_add:
            raise HTTPException(status_code=404, detail=f"User '{user_to_add}' not found")
        
        # Check if user is already in channel
        existing = db.query(ChannelUser).filter(
            ChannelUser.channel_id == channel_id,
            ChannelUser.user_id == user_to_add.id
        ).first()
        
        if existing:
            raise HTTPException(status_code=400, detail="User is already in this channel")
        
        # Add user to channel
        channel_user = ChannelUser(
            channel_id=channel_id,
            user_id=user_to_add.id,
            added_by=current_user.id
        )
        db.add(channel_user)
        db.commit()
        
        logger.info("User %s added to channel %s by %s", username, channel_id, current_user.username)
        
        return {
            "message": "User added to channel successfully",
            "username": username,
            "channel_id": channel_id
        }
        
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error("Failed to add user to channel: %s", str(e))
        raise HTTPException(status_code=500, detail="Failed to add user to channel")


def has_channel_access(db: Session, user_id: int, channel_id: int) -> bool:
    """Check if user has access to a channel"""
    # Check if channel exists and is active
    channel = db.query(Channel).filter(
        Channel.id == channel_id,
        Channel.is_active == 1
    ).first()
    
    if not channel:
        return False
    
    # Check if user is admin of the channel
    if channel.admin_user_id == user_id:
        return True
    
    # Check if user is added to the channel
    channel_user = db.query(ChannelUser).filter(
        ChannelUser.channel_id == channel_id,
        ChannelUser.user_id == user_id
    ).first()
    
    if channel_user:
        return True
    
    # Check if user is super admin
    user = db.query(User).filter(User.id == user_id).first()
    if user and user.role == "super":
        return True
    
    return False




@router.delete("/{channel_id}/users/{user_id}")
async def remove_user_from_channel(
    channel_id: int,
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Remove a user from a channel (admin only)"""
    
    try:
        channel = db.query(Channel).filter(
            Channel.id == channel_id,
            Channel.is_active == 1
        ).first()
        
        if not channel:
            raise HTTPException(status_code=404, detail="Channel not found")
        
        # Check permissions - only admin or super admin can remove users
        if current_user.role != "super" and channel.admin_user_id != current_user.id:
            raise HTTPException(status_code=403, detail="Only channel admin can remove users")
        

        
        # Find and remove channel user
        channel_user = db.query(ChannelUser).filter(
            ChannelUser.channel_id == channel_id,
            ChannelUser.user_id == user_id
        ).first()
        
        if not channel_user:
            raise HTTPException(status_code=404, detail="User not found in this channel")
        
        db.delete(channel_user)
        db.commit()
        
        logger.info("User %s removed from channel %s by %s", user_id, channel_id, current_user.username)
        
        return {
            "message": "User removed from channel successfully",
            "user_id": user_id,
            "channel_id": channel_id
        }
        
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error("Failed to remove user from channel: %s", str(e))
        raise HTTPException(status_code=500, detail="Failed to remove user from channel")


@router.delete("/{channel_id}/files/{file_id}")
async def delete_file_from_channel(
    channel_id: int,
    file_id: str,
    permanent: bool = True,  # Query parameter for permanent deletion
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete a file from a channel
    - Only channel admin, file owner, or super admin can delete files
    - permanent=false: Remove from channel only (default)
    - permanent=true: Completely delete file and embeddings from database
    """
    logger.info("Deleting file %s from channel %s by user %s (permanent=%s)", 
                file_id, channel_id, current_user.username, permanent)
    try:
        # Check if channel exists and is active
        channel = db.query(Channel).filter(
            Channel.id == channel_id,
            Channel.is_active == 1
        ).first()
        if not channel:
            raise HTTPException(status_code=404, detail="Channel not found")
        # Check if file exists in this channel
        file_record = db.query(FileRecord).filter(
            FileRecord.file_id == file_id,
            FileRecord.channel_id == channel_id
        ).first()
        if not file_record:
            raise HTTPException(status_code=404, detail="File not found in this channel")
        # Check permissions
        is_super_admin = current_user.role == "super"
        is_channel_admin = channel.admin_user_id == current_user.id
        is_file_owner = file_record.user_id == current_user.id
        if not (is_super_admin or is_channel_admin):
            raise HTTPException(
                status_code=403, 
                detail="Only channel admin, file owner, or super admin can delete files"
            )
        if permanent:
            # PERMANENT DELETE - Remove file and all embeddings completely
            logger.warning("Performing PERMANENT deletion of file %s by %s", 
                          file_id, current_user.username)
            # 1. Delete all embeddings for this file
            embeddings_deleted = db.query(FileEmbeddings).filter(
                FileEmbeddings.file_id == file_id
            ).delete()
            logger.debug("Deleted %d embeddings for file %s", embeddings_deleted, file_id)

            # 3. Delete the file record
            db.delete(file_record)
            db.commit()
            logger.warning("File %s PERMANENTLY deleted from database by %s", 
                          file_id, current_user.username)
            return {
                "message": "File permanently deleted",
                "file_id": file_id,
                "filename": file_record.filename,
                "channel_id": channel_id,
                "deletion_type": "permanent",
                "items_deleted": {
                    "embeddings": embeddings_deleted,
                }
            }
    
            
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error("Failed to delete file from channel: %s", str(e))
        raise HTTPException(status_code=500, detail="Failed to delete file from channel")