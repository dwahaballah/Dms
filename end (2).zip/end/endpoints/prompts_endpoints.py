import logging
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from endpoints.user_endpoints import get_current_user
# Adjust these imports according to your project structure.
from database import get_db
from models import SystemPrompt
from models import User
router = APIRouter()

@router.get("/user/prompts")
def get_prompts(
    # current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    prompts = db.query(SystemPrompt).filter(SystemPrompt.user_id == current_user.id).filter(SystemPrompt.channel_id == None).all()
    prompt_list = [
        {"id": prompt.id, "name": prompt.name, "content": prompt.content}
        for prompt in prompts
    ]
    logging.info(f"Returning prompts for user {current_user.id}: {prompt_list}")
    return JSONResponse(content={"prompts": prompt_list})

 

@router.post("/add")
def add_system_prompt(
    data: dict,
    # current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    name = data.get("name")
    content = data.get("content")
    if not name or not content:
        raise HTTPException(status_code=400, detail="Both name and content are required.")
 
    existing_prompt = db.query(SystemPrompt).filter(
        SystemPrompt.name == name,
        SystemPrompt.user_id == current_user.id
    ).first()
 
    prompt = SystemPrompt(name=name, content=content, user_id=current_user.id)
    db.add(prompt)
    db.commit()
    db.refresh(prompt)
    return JSONResponse(content={"message": "System prompt added successfully", "id": prompt.id})
 
 
@router.put("/{prompt_id}")
def edit_system_prompt(
    prompt_id: int,
    data: dict,
    # current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    prompt = db.query(SystemPrompt).filter(
        SystemPrompt.id == prompt_id,
        SystemPrompt.user_id == current_user.id
    ).first()
 
    if not prompt:
        raise HTTPException(status_code=404, detail="System prompt not found or unauthorized.")
    prompt.name = data.get("name", prompt.name)
    prompt.content = data.get("content", prompt.content)
    db.commit()
    return JSONResponse(content={"message": "System prompt updated successfully", "id": prompt.id})
 
@router.delete("/{prompt_id}")

def delete_system_prompt(

    prompt_id: int,

    # current_user: User = Depends(get_current_user),

    db: Session = Depends(get_db)

):

    prompt = db.query(SystemPrompt).filter(

        SystemPrompt.id == prompt_id,

        SystemPrompt.user_id == current_user.id

    ).first()
 
    if not prompt:

        raise HTTPException(status_code=404, detail="System prompt not found or unauthorized.")
 
    db.delete(prompt)

    db.commit()

    return JSONResponse(content={"message": "System prompt deleted successfully"})
 