# main.py
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base
from typing import Optional
from datetime import datetime, timedelta
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timedelta
from typing import Optional
import re
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr,validator
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from os import getenv
from dotenv import load_dotenv
from sqlalchemy import Column, Integer, String, Text, Identity
import os
from models import User
from utils.ldap_config import test_user_authentication
load_dotenv()


# # Read values from environment variables
user = os.getenv("ORACLE_USER")
password = os.getenv("ORACLE_PASSWORD")
host = os.getenv("ORACLE_HOST")
port = os.getenv("ORACLE_PORT")
service_name = os.getenv("ORACLE_SERVICE_NAME")

# ------------------------------------------------------------------
# 3. Connection URL
# -----------------------------------------------------------------

DATABASE_URL = f"oracle+oracledb://{user}:{password}@{host}:{port}/?service_name={service_name}"

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,        # keeps long‑lived connections fresh
    echo=False                 # flip to True while debugging SQL
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
# Define a simple Users table


Base.metadata.create_all(bind=engine)

# ============== Auth / Security ==============
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")  # our login endpoint

SECRET_KEY = "thepass"  # do not store in code for real usage
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 10000  # example

def get_password_hash(password: str):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_user_by_username(db, username: str):
    return db.query(User).filter(User.username == username).first()

# ============== Pydantic Schemas ==============
class RegisterModel(BaseModel):
    username: str
    email: EmailStr
    password: str

    @validator('username')
    def username_must_be_alphanumeric(cls, v):
        if not re.match("^[a-zA-Z0-9_.-]{3,20}$", v):
            raise ValueError("Username must be 3-20 characters and only contain letters, numbers, dots, underscores or dashes")
        return v.strip()

    @validator('password')
    def password_strong(cls, v, values):
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters long")
        if not re.search(r'[A-Z]', v):
            raise ValueError("Password must include at least one uppercase letter")
        if not re.search(r'[a-z]', v):
            raise ValueError("Password must include at least one lowercase letter")
        if not re.search(r'[0-9]', v):
            raise ValueError("Password must include at least one number")
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError("Password must include at least one special character")

        if 'username' in values and v == values['username']:
            raise ValueError("Password cannot be the same as the username")
        if 'email' in values and v == values['email']:
            raise ValueError("Password cannot be the same as the email")
        return v

class LoginModel(BaseModel):
    username: str
    password: str

    @validator('username', 'password')
    def not_empty(cls, v):
        if not v or v.strip() == "":
            raise ValueError("Field cannot be blank")
        return v.strip()

class TokenData(BaseModel):
    username: Optional[str] = None

# ============== FastAPI app ==============
router = APIRouter()



@router.post("/register")
def register_user(user: RegisterModel, db=Depends(get_db)):
    # Check if user already exists
    db_user = get_user_by_username(db, user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered.")

    # Or check if email is taken
    existing_email = db.query(User).filter(User.email == user.email).first()
    if existing_email:
        raise HTTPException(status_code=400, detail="Email already in use.")

    # Hash password and store user
    hashed_pw = get_password_hash(user.password)
    new_user = User(username=user.username, email=user.email, hashed_password=hashed_pw)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return {"message": "User registered successfully!"}

@router.post("/login")
def login_user(form_data: OAuth2PasswordRequestForm = Depends(), db=Depends(get_db)):
    try:
        # OAuth2PasswordRequestForm gives us username & password from form fields
        username = form_data.username
        password = form_data.password

        # Authenticate user
        sso = test_user_authentication(username, password)
        if not sso:
            raise HTTPException(status_code=400, detail="Incorrect username or password")

        # Check if user exists in the database
        db_user = get_user_by_username(db, username)

        if not db_user:
            # Hash password and store user
            hashed_pw = get_password_hash("password")
            new_user = User(username=username, hashed_password=hashed_pw)
            try:
                db.add(new_user)
                db.commit()
                db.refresh(new_user)
                db_user = get_user_by_username(db, username)
            except SQLAlchemyError as e:
                db.rollback()  # Rollback the transaction in case of an error
                raise HTTPException(status_code=500, detail="Database error occurred")

        # Create a JWT token
        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": db_user.username, "user_id": db_user.id},  # 'sub' is a standard claim
            expires_delta=access_token_expires
        )
        return {"access_token": access_token, "token_type": "bearer"}

    except HTTPException as http_exc:
        # Re-raise HTTP exceptions to preserve the original error details
        raise http_exc
    except Exception as e:
        # Catch any other unexpected errors
        raise HTTPException(status_code=500, detail="An unexpected error occurred")

# def login_user(form_data: OAuth2PasswordRequestForm = Depends(), db=Depends(get_db)):
#     # OAuth2PasswordRequestForm gives us username & password from form fields
#     username = form_data.username
#     password = form_data.password

#     sso = test_user_authentication(username, password)

#     db_user = get_user_by_username(db, username)
#     if not db_user:
#         raise HTTPException(status_code=400, detail="Incorrect username or password")

#     if not verify_password(password, db_user.hashed_password):
#         raise HTTPException(status_code=400, detail="Incorrect username or password")

#     # create a JWT token
#     access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
#     access_token = create_access_token(
#         data={"sub": db_user.username, "user_id": db_user.id},  # 'sub' is a standard claim
#         expires_delta=access_token_expires
#     )
#     return {"access_token": access_token, "token_type": "bearer"}

# If you want to allow direct JSON login (not using form-data), you can do:
@router.post("/login/json")
def login_user_json(credentials: LoginModel, db=Depends(get_db)):
    username = credentials.username
    password = credentials.password
    db_user = get_user_by_username(db, username)
    if not db_user or not verify_password(password, db_user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect username or password")

    access_token = create_access_token(data={"sub": db_user.username})
    return {"access_token": access_token, "token_type": "bearer"}

# Protected route example
@router.get("/profile")
def read_profile(token: str = Depends(oauth2_scheme), db=Depends(get_db)):
    # We decode the JWT token
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Could not validate token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Could not validate token")

    user = get_user_by_username(db, username)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return {"username": user.username, "email": user.email}
