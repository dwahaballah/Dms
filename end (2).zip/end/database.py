import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv
from models import Base  # Your declarative models
import oracledb
import platform

# ------------------------------------------------------------------
# 1. Enable thick mode for Oracle DB
# ------------------------------------------------------------------

if platform.system() == "Windows":
    oracledb.init_oracle_client(lib_dir="C:\\Users\\dhamdy\\Downloads\\instantclient-basic-windows.x64-23.9.0.25.07\\instantclient_23_9")
else:
    # Optionally enable thick mode
    oracle_client_path = os.getenv("ORACLE_CLIENT_LIB_DIR")
    if oracle_client_path:
        oracledb.init_oracle_client(lib_dir=oracle_client_path)
# ------------------------------------------------------------------
# 2. Load environment variables
# ------------------------------------------------------------------
load_dotenv()

# Read values from environment variables
user = os.getenv("ORACLE_USER")
password = os.getenv("ORACLE_PASSWORD")
host = os.getenv("ORACLE_HOST")
port = os.getenv("ORACLE_PORT")
service_name = os.getenv("ORACLE_SERVICE_NAME")

# ------------------------------------------------------------------
# 3. Connection URL
# -----------------------------------------------------------------

DATABASE_URL = f"oracle+oracledb://{user}:{password}@{host}:{port}/?service_name={service_name}"


# ------------------------------------------------------------------
# 4. Engine
# ------------------------------------------------------------------
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,   # Avoids connection issues with idle APIs
    pool_recycle=3600,    # Optional: force reconnect every hour
    echo=False ,          # Set to True to log raw SQL queries

 
)

# ------------------------------------------------------------------
# 5. Session Factory
# ------------------------------------------------------------------
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    """
    Dependency to provide a database session.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ------------------------------------------------------------------
# 6. Create Tables (Development Only)
# ------------------------------------------------------------------
# In production, use Alembic for migrations.
#Base.metadata.create_all(bind=engine)

# ------------------------------------------------------------------
# 7. Test Connection
# ------------------------------------------------------------------
try:
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 'Oracle connection successful!' FROM dual"))
        print(result.scalar())
except Exception as e:
    print("Connection failed:", e)