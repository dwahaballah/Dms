import json
import requests
from fastapi import HTTPException
import numpy as np
import faiss
import re
from dotenv import load_dotenv
import os
load_dotenv()


EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL")

# In-memory store for file details (for fast access and FAISS index updates)
embedding_store = {}  # Format: {file_id: { "filename": ..., "text": ..., "embedding": [...] } }
embedding_dim = 1536  # Dimension for the embedding model
faiss_index = faiss.IndexFlatL2(embedding_dim)
faiss_file_ids = []  # Maps FAISS index positions to our file IDs

# Placeholder for tokenization
def count_tokens(text: str) -> int:
    """
    Count the number of tokens in the text.
    If text is a list, join the elements into a single string.
    """
    if isinstance(text, list):
        text = " ".join(text)
    # Simple tokenization by splitting on spaces (adjust if needed for the new model)
    tokens = text.split()
    return len(tokens)

def get_embedding_old(text: str) -> list:
    """
    Generate embeddings for the given text using the new embedding model API.
    """

    MAX_TOKENS = 6001  # Approximate token limit

    # Count tokens using an accurate tokenizer
    token_count = count_tokens(text)
    print("token_count:", token_count)  # Replace with logging in production

    if token_count <= MAX_TOKENS:
        try:
            # Send a POST request to the embedding model API
            response = requests.post(
                url=EMBEDDING_MODEL,
                headers={"Content-Type": "application/json"},
                json={"sentences": [text]}
            )
            if response.status_code == 200:
                embedding = response.json()["embeddings"][0]
                return embedding
            else:
                raise HTTPException(
                    status_code=500,
                    detail=f"Error generating embedding: {response.text}"
                )
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error generating embedding: {str(e)}"
            )
    else:
        # Split text into chunks if it exceeds the token limit
        tokens = text.split()  # Simple tokenization by splitting on spaces
        chunks = []

        # Split tokens into chunks of MAX_TOKENS size
        for i in range(0, len(tokens), MAX_TOKENS):
            token_slice = tokens[i:i + MAX_TOKENS]
            chunk_text = " ".join(token_slice)
            chunks.append(chunk_text)
        print("len - chunks:", len(chunks))

        embeddings = []
        for idx, chunk in enumerate(chunks):
            try:
                # Send a POST request for each chunk
                response = requests.post(
                    url=EMBEDDING_MODEL,
                    headers={"Content-Type": "application/json"},
                    json={"sentences": [chunk]}
                )
                if response.status_code == 200:
                    embedding = np.array(response.json()["embeddings"][0])
                    embeddings.append(embedding)
                else:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Error generating embedding for chunk {idx}: {response.text}"
                    )
            except Exception as e:
                raise HTTPException(
                    status_code=500,
                    detail=f"Error generating embedding for chunk {idx}: {str(e)}"
                )

        # Compute the average of all chunk embeddings
        avg_embedding = np.mean(embeddings, axis=0)
        return avg_embedding.tolist()

MAX_TOKENS = 6001  # Adjust as needed

def get_embedding(texts: list[str]) -> list[list[float]]:
    """
    Generate embeddings for a list of strings using the embedding API.
    If a string exceeds the token limit, it will be chunked and averaged.
    """
    embeddings = []

    for text in texts:
            try:
                response = requests.post(
                    url=EMBEDDING_MODEL,
                    headers={"Content-Type": "application/json"},
                    json={"sentences": [text]}
                )
                if response.status_code == 200:
                    embedding = response.json()["embeddings"][0]
                    embeddings.append(embedding)
                else:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Error generating embedding: {response.text}"
                    )
            except Exception as e:
                raise HTTPException(
                    status_code=500,
                    detail=f"Error generating embedding: {str(e)}"
                )
    return embeddings

