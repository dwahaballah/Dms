import requests, io
import mimetypes
import os
from dotenv import load_dotenv

load_dotenv()

OPEN_TEXT_BASE_URL = os.getenv("OPEN_TEXT_BASE_URL")
OPEN_TEXT_USERNAME = os.getenv("OPEN_TEXT_USERNAME")
OPEN_TEXT_PASSWORD = os.getenv("OPEN_TEXT_PASSWORD")

class OpenTextClient:
    def __init__(self):
        self.base_url = OPEN_TEXT_BASE_URL.rstrip('/')
        self.username = OPEN_TEXT_USERNAME
        self.password = OPEN_TEXT_PASSWORD
        self.token = None

    def get_token(self):
        url = f"{self.base_url}/otcs/llisapi.dll/api/v1/auth"
        form_data = {
            'username': (None, self.username),
            'password': (None, self.password)
        }
        response = requests.post(url, data=form_data, timeout=5)
        if response.status_code == 200:
            self.token = response.json().get('ticket')
            return self.token
        else:
            raise Exception(f"Failed to get token: {response.status_code} - {response.text}")

    def upload_document(self, file_path: str, name: str, parent_id: str = "11774958", doc_type: str = "144"):
        if not self.token:
            raise Exception("Authentication token not available. Call get_token() first.")


        mime_type, _ = mimetypes.guess_type(file_path)

        if mime_type is None:
            mime_type = 'applicaiton/octet-stream'

        headers = {
            'otcsticket': self.token, 
        }
        files = [
            ('file', (name, open(file_path, 'rb'), mime_type))
        ]
        payload = {
            'type': doc_type,
            'parent_id': parent_id,
            'name': name
        }
        
        count = 1
        url = f"http://as10409aufal02/otcs/llisapi.dll/api/v2/nodes"
        
        con = True
        while con:
            #print("res code", response.status_code)
            response = requests.request("POST", url, headers=headers, data=payload, files=files)

            if response.status_code == 200:
                con = False
                print("id", response.json()['results']['data']['properties']['id'] )
                return response.json()['results']['data']['properties']['id'] if response.ok else f"Upload failed: {response.status_code} - {response.text}"
            else:
                payload['name'] = f"{name}({count})"
                count += 1
            if count > 20:
                break

    def download_document(self, node_id: str):
        if not self.token:
            raise Exception("Authentication token not available. Call get_token() first.")

        url = f"http://as10409aufal02/otcs/cs.exe/api/v2/nodes/{node_id}/content"
        headers = {'otcsticket': self.token}
        payload = {'parent_id': 11774958}
        response = requests.get(url, headers=headers, params=payload, timeout=5)
        print("file response \n", response)
        if response.status_code == 200:
            print("@@@", response.content)
            return response.content
        else:
            print(f"Failed to download. Status code: {response.status_code}")
            print(response.text)


    def delete_document(self, node_id: str):
        if not self.token:
            raise Exception("Authentication token not available. Call get_token() first.")

        url = f"http://as10409aufal02/otcs/cs.exe/api/V2/nodes/{node_id}"
        headers = {'otcsticket': self.token}
        response = requests.delete(url, headers=headers, stream=True, timeout=5)

        if response.status_code == 200:
            print("file deleted from opentext")
        else:
            print(f"Failed to deleted. Status code: {response.status_code}")
            print(response.text)


# client = OpenTextClient()

# token = client.get_token()

# client.download_document_(14361168)

# #client.upload_document(file_path="C:\\Users\\kelella\\Desktop\\Document Assistant\\computer science_test.pdf", name="computer science_test")