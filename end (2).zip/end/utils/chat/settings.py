import os
from openai import OpenAI

# client = OpenAI()
MAX_TOKENS = 500
SEARXNG_URL = os.getenv("SEARXNG_URL", "https://searxng.goai247.com/search")
import datetime
import pytz

def get_current_datetime_location():
    """
    Retrieves the current date, time, and location (Cairo, Egypt).

    Returns:
        tuple: (current_date, current_time, current_location)
    """
    tz = pytz.timezone("Africa/Cairo")  # Set to Egypt timezone
    now = datetime.datetime.now(tz)
    current_date = now.strftime("%Y-%m-%d")
    current_time = now.strftime("%H:%M:%S")
    current_location = "Cairo, Egypt"
    
    return current_date, current_time, current_location
