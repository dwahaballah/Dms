from sqlalchemy.orm import Session
from models import FileRecord

def get_selected_files(db: Session, selected_file_ids: list):
    """
    Fetches file contents from the database based on selected file IDs.

    Args:
        db (Session): Database session.
        selected_file_ids (list): List of file IDs.

    Returns:
        tuple: (Formatted file context, List of file names)
    """
    file_contexts = []
    file_names = []
    
    for file_id in selected_file_ids:
        file_entry = db.query(FileRecord).filter_by(file_id=str(file_id)).first()
        if file_entry:
            file_names.append(f"{file_entry.filename}, total file pages: {file_entry.source}")
            file_contexts.append(f"File: {file_entry.filename}\n{file_entry.content}")
            

    return "\n\n".join(file_contexts) or "No files selected.", file_names
