import re
def extract_needed_data(input_string):
    """
    Extracts the 'next_action', 'standalone_question', and 'pages' from the input string.
   
    Args:
        input_string (str): The string containing all the data.
   
    Returns:
        dict: A dictionary containing 'next_action', 'standalone_question', and 'pages'.
    """
    try:
        # Use regular expressions to extract the next_action, standalone_question, and pages
        next_action_match = re.search(r'"next_action":\s*"([^"]+)"', input_string)
        standalone_question_match = re.search(r'"standalone_question":\s*"([^"]+)"', input_string)
        pages_match = re.search(r'"pages":\s*(\[[^\]]*\]|null)', input_string)
       
        # Extract the values if matches are found
        next_action = next_action_match.group(1) if next_action_match else None
        standalone_question = standalone_question_match.group(1) if standalone_question_match else None
        pages = eval(pages_match.group(1)) if pages_match and pages_match.group(1) != "null" else None
       
        # Return the extracted data as a dictionary
        return {
            "next_action": next_action,
            "standalone_question": standalone_question,
            "pages": pages
        }
        print({"next_action": next_action,
            "standalone_question": standalone_question,
            "pages": pages})
    except Exception as e:
        # Handle any errors gracefully
        print(f"Error extracting data: {e}")
        return None

def parse_chatbot_output(full_text: str):
    """
    Parses full chatbot response into the answer and source info.
   
    Returns:
        dict: {
            response_text,
            file_name,
            page_number,
            opentext_storage_id
        }
    """
    # Match response before Source (multi-line friendly)
    response_match = re.split(r"\n*Source:", full_text, maxsplit=1)
    source_match = re.search(
        r"([\w\-\.]+),\s*page\s*(\d+),\s*opentxt_storage_id:\s*(\d+)",
        full_text
    )

    if response_match and len(response_match) > 1 and source_match:
        return {
            "response_text": response_match[0].strip(),
            "file_name": source_match.group(1),
            "page_number": int(source_match.group(2))
        }
    return None

