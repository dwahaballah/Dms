import asyncio
import logging
from utils.chat.conversation import update_conversation

TYPING_DELAY = 0.00000001     # 5�ms per character � tweak if you want it faster/slower
LOG_EVERY    = 200        # how many characters before we print a progress log

def stream_response(
    response_text: str,
    db,
    conversation,
    user_message: str,
    conversation_id: str,
    history: list,
):
    """
    Yield the LLM answer **character-by-character** so the user
    has time to click Stop.  Save to DB only if the stream completes.
    """

    async def stream_generator():
        accumulated = ""
        completed   = False
        chars_sent  = 0

        try:
            for ch in response_text:
                accumulated += ch
                chars_sent  += 1
                if chars_sent % LOG_EVERY == 0:
                    logging.debug("?? streamed %d chars so far", chars_sent)

                # hand one character to the client
                yield ch.encode("utf-8")
                await asyncio.sleep(TYPING_DELAY)

            completed = True   # ? only reached when loop finishes normally
        except asyncio.CancelledError:
            logging.warning("?? client aborted after %d chars", chars_sent)
            raise                      # bubble up so FastAPI closes the socket
        finally:
            if completed:
                logging.debug("?? saving full answer (%d chars)", len(accumulated))
                history.extend([
                    {"role": "user",      "content": user_message},
                    {"role": "assistant", "content": accumulated},
                ])
                update_conversation(db, conversation, history)

    return stream_generator()
