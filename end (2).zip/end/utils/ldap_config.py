from ldap3 import Server, Connection, ALL, SUBTREE
from ldap3.core.exceptions import LDAPException, LDAPBindError
from dotenv import load_dotenv
import os
load_dotenv()


LDAP_server = os.getenv("LDAP_server")
LDAP_base_dn = os.getenv("LDAP_base_dn")
LDAP_bind_dn = os.getenv("LDAP_bind_dn")
LDAP_bind_password = os.getenv("LDAP_bind_password")
LDAP_user_filter = os.getenv("LDAP_user_filter")
LDAP_group_filter = os.getenv("LDAP_group_filter")
LDAP_user_search_base = os.getenv("LDAP_user_search_base")

LDAP_CONFIG = {
    "server": LDAP_server,
    "base_dn": LDAP_base_dn,
    "bind_dn": LDAP_bind_dn,
    "bind_password": LDAP_bind_password,  
    "user_filter": LDAP_user_filter,
    "group_filter": LDAP_group_filter,
    "user_search_base": LDAP_user_search_base
} 

def test_user_authentication(test_username="", test_password=""):
    """Test user authentication"""

    if not test_username:
        test_username = input("Enter username for authentication test: ").strip()
    if not test_password:
        import getpass
        test_password = getpass.getpass("Enter password: ")
    try:
        server = Server(LDAP_CONFIG["server"], get_info=ALL, use_ssl=True)
        # First get user DN
        service_conn = Connection(
            server,
            user=LDAP_CONFIG["bind_dn"],
            password=LDAP_CONFIG["bind_password"],
            auto_bind=True
        )
        user_filter = LDAP_CONFIG["user_filter"].format(test_username)
        service_conn.search(
            search_base=LDAP_CONFIG["user_search_base"],
            search_filter=user_filter,
            search_scope=SUBTREE,
            attributes=['distinguishedName']
        )
        if not service_conn.entries:
            print("✗ User not found for authentication")
            return False
        user_dn = service_conn.entries[0].distinguishedName.value
        service_conn.unbind()
        # Test user authentication
        user_conn = Connection(
            server,
            user=user_dn,
            password=test_password,
            auto_bind=True
        )
        print("✓ User authentication successful")
        print(f"  User DN: {user_dn}")
        user_conn.unbind()
        return True
    except LDAPBindError as e:
        print(f"✗ User authentication failed: {e}")
        print("  Invalid credentials")
        return False
    except Exception as e:
        print(f"✗ Authentication error: {e}")
        return False